package com.registro.usuarios.servicio;

import java.util.List;

import com.registro.usuarios.modelo.Plataforma;

public interface PlataformaServicio {
	
	public abstract List<Plataforma> listaPlataforma();
}
