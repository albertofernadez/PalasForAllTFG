package com.registro.usuarios.servicio;

import com.registro.usuarios.modelo.DetalleOrden;

public interface IDetalleOrdenService {
	DetalleOrden save (DetalleOrden detalleOrden);
}
