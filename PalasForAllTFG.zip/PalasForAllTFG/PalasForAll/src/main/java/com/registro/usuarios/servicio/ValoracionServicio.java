package com.registro.usuarios.servicio;

public class ValoracionServicio {

}
