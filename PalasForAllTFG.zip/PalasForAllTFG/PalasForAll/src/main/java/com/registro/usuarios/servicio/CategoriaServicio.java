package com.registro.usuarios.servicio;

import java.util.List;

import com.registro.usuarios.modelo.Categoria;

public interface CategoriaServicio {
	
	public abstract List<Categoria> listaCategoria();
}
